# Assignment 1 — Image Filtering

## Contents

- `assignment1_image_filtering.ipynb` — notebook version of the assignment, organized into cells by part (Part 1–4), with all figures and results rendered inline. Already executed top-to-bottom with no errors; every printed number matches the values in `report.pdf`.
- `assignment1_image_filtering.py` — script version of the same implementation. Generates every figure into `figures/` and prints every requested numerical result to stdout. Submit either this or the notebook, not both, unless your instructor wants both.
- `report.pdf` — 4-page report with all figures, numerical results, and written answers.
- `figures/` — all generated figures (from the `.py` run).
- `test_image.webp` — the single fixed test image used throughout (brick wall with sky, chosen for its mix of flat regions and fine texture).

## Environment (obtained programmatically, not guessed)

Python version: 3.12.3
OpenCV version: 4.13.0

(printed at the top of every run of `assignment1_image_filtering.py` via `sys.version` and `cv2.__version__`)

## How to run

```bash
pip install numpy opencv-python matplotlib
python3 assignment1_image_filtering.py
```

This reproduces every number in the report and regenerates every figure in `figures/`.
